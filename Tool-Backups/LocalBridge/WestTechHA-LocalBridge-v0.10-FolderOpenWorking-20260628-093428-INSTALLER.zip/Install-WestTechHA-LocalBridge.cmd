@echo off
setlocal

set "SRC=%~dp0"
set "BRIDGE_ROOT=%LOCALAPPDATA%\WestTechHA\LocalBridge"
set "PYTHON_EXE=C:\Python314\python.exe"

echo Installing WestTechHA Local Bridge known-good package...

if not exist "%PYTHON_EXE%" (
  echo ERROR: Python not found:
  echo   %PYTHON_EXE%
  pause
  exit /b 1
)

mkdir "%BRIDGE_ROOT%" >nul 2>nul
mkdir "%BRIDGE_ROOT%\logs" >nul 2>nul
mkdir "%BRIDGE_ROOT%\backups" >nul 2>nul
mkdir "%BRIDGE_ROOT%\cache" >nul 2>nul

copy /Y "%SRC%WestTechHA-LocalBridge-v0.10.py" "%BRIDGE_ROOT%\WestTechHA-LocalBridge-v0.10.py" >nul
copy /Y "%SRC%bridge-config.json" "%BRIDGE_ROOT%\bridge-config.json" >nul
copy /Y "%SRC%Start-WestTechHA-LocalBridge.cmd" "%BRIDGE_ROOT%\Start-WestTechHA-LocalBridge.cmd" >nul
copy /Y "%SRC%Stop-WestTechHA-LocalBridge.cmd" "%BRIDGE_ROOT%\Stop-WestTechHA-LocalBridge.cmd" >nul
copy /Y "%SRC%Health-WestTechHA-LocalBridge.cmd" "%BRIDGE_ROOT%\Health-WestTechHA-LocalBridge.cmd" >nul

call "%BRIDGE_ROOT%\Stop-WestTechHA-LocalBridge.cmd" >nul 2>nul
call "%BRIDGE_ROOT%\Start-WestTechHA-LocalBridge.cmd"

timeout /t 3 >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-RestMethod 'http://127.0.0.1:8791/health' | ConvertTo-Json -Depth 12"

echo.
echo Install complete.
pause
