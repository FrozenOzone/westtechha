@echo off
setlocal

powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-RestMethod 'http://127.0.0.1:8791/health' | ConvertTo-Json -Depth 12 } catch { Write-Host $_; exit 1 }"
pause
