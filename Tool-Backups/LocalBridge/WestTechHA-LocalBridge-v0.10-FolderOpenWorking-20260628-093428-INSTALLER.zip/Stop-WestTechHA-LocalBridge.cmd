@echo off
setlocal

echo Stopping WestTechHA Local Bridge on port 8791...

for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":8791 .*LISTENING"') do (
  echo Stopping PID %%P
  taskkill /PID %%P /F >nul 2>nul
)

exit /b 0
