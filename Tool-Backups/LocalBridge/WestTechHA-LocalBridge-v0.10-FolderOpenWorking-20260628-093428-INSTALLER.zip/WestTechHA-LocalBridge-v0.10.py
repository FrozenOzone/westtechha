﻿#!/usr/bin/env python3
"""
WestTechHA Local Bridge v0.10

Compatibility endpoint layer for the server-served portal.

Binds to 127.0.0.1 only.
Keeps v0.3 approved launch behavior.
Adds old portal API-compatible paths under /api/v1/tools/... so the server page can
ask the Windows bridge to check local Windows files without using the old 8787 backend.

No arbitrary command execution.
No arbitrary paths.
No caller-supplied arguments.
"""

from __future__ import annotations

import json
import os
import platform
import socket
import subprocess
import sys
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Tuple


BRIDGE_ROOT = Path(os.environ.get("WESTTECH_LOCAL_BRIDGE_ROOT", Path.home() / "AppData" / "Local" / "WestTechHA" / "LocalBridge"))
CONFIG_PATH = BRIDGE_ROOT / "bridge-config.json"
PID_PATH = BRIDGE_ROOT / "bridge.pid"


def load_config() -> Dict[str, Any]:
    with CONFIG_PATH.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


CONFIG = load_config()
BIND_HOST = str(CONFIG.get("bind_host", "127.0.0.1"))
PORT = int(CONFIG.get("port", 8791))
SERVER_PORTAL_URL = str(CONFIG.get("server_portal_url", "http://192.168.1.244:8790")).rstrip("/")
ALLOWED_ORIGINS = set(CONFIG.get("allowed_origins", []))


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def log_event(message: str) -> None:
    log_dir = Path(str(CONFIG.get("logs_dir", BRIDGE_ROOT / "logs")))
    log_dir.mkdir(parents=True, exist_ok=True)
    with (log_dir / "bridge-events.log").open("a", encoding="utf-8") as f:
        f.write(f"{now_iso()} {message}\n")


def configured_tools() -> List[Dict[str, Any]]:
    return list(CONFIG.get("local_tools", []))


def normalize(value: Any) -> str:
    return str(value or "").strip().lower()


def find_tool_by_action(action_key: str) -> Dict[str, Any] | None:
    wanted = normalize(action_key)
    for tool in configured_tools():
        if normalize(tool.get("action_key")) == wanted:
            return tool
    return None


def _flatten_body_parts(value: Any) -> List[str]:
    parts: List[str] = []
    if value is None:
        return parts
    if isinstance(value, dict):
        for key, inner in value.items():
            parts.append(str(key))
            parts.extend(_flatten_body_parts(inner))
        return parts
    if isinstance(value, (list, tuple, set)):
        for inner in value:
            parts.extend(_flatten_body_parts(inner))
        return parts
    parts.append(str(value))
    return parts


def _squash(value: Any) -> str:
    return "".join(ch for ch in normalize(value) if ch.isalnum())


def _candidate_strings_for_tool(tool: Dict[str, Any]) -> List[str]:
    candidates: List[str] = []
    for key in ("action_key", "key", "display_name", "category", "expected_path", "working_directory"):
        raw = tool.get(key)
        if raw:
            candidates.append(str(raw))
            try:
                candidates.append(Path(str(raw)).name)
            except Exception:
                pass

    for raw in tool.get("id_match", []):
        if raw:
            candidates.append(str(raw))

    # Compatibility aliases from older portal data/labels.
    action = normalize(tool.get("action_key"))
    display = normalize(tool.get("display_name"))
    if action == "launch_production_tool" or "esp32" in display:
        candidates.extend([
            "launch_production_tool",
            "approved action key launch_production_tool",
            "westtech esp32 production tool",
            "esp32 production tool",
            "production tool",
            "Start-WT-ESP32-Production-Tool.cmd",
            "WT-ESP32-Production-Tool",
            "esp32-production-tool",
            "esp32_production_tool",
            "production-tool",
        ])
    elif action == "run_website_updater" or "website updater" in display:
        candidates.extend([
            "run_website_updater",
            "westtechha website updater",
            "website updater",
            "Run WestTechHA Website Menu.cmd",
            "website-updater",
        ])
    elif action == "run_creality_print" or "creality" in display:
        candidates.extend([
            "run_creality_print",
            "creality print",
            "CrealityPrint.exe",
            "creality-print",
        ])

    cleaned: List[str] = []
    seen = set()
    for candidate in candidates:
        text = normalize(candidate)
        if not text:
            continue
        if text not in seen:
            seen.add(text)
            cleaned.append(text)
    return cleaned


def find_tool_from_body(body: Dict[str, Any]) -> Dict[str, Any] | None:
    # v0.5: older portal calls can send tool identity nested inside item/process/selection objects,
    # not only as direct id/action_key fields. Flatten the full JSON body and score matches.
    parts = _flatten_body_parts(body)
    text = normalize(" ".join(parts))
    squashed = _squash(" ".join(parts))

    scored: List[Tuple[int, Dict[str, Any], List[str]]] = []
    for tool in configured_tools():
        candidates = _candidate_strings_for_tool(tool)
        score = 0
        reasons: List[str] = []

        action = normalize(tool.get("action_key"))
        key = normalize(tool.get("key"))
        display = normalize(tool.get("display_name"))

        for candidate in candidates:
            candidate_squashed = _squash(candidate)
            if not candidate:
                continue

            if action and (action in text or _squash(action) in squashed):
                score += 120
                reasons.append(f"action:{action}")
                break

            if key and (key in text or _squash(key) in squashed):
                score += 90
                reasons.append(f"key:{key}")
                break

            if display and (display in text or _squash(display) in squashed):
                score += 90
                reasons.append(f"display:{display}")
                break

            if len(candidate) >= 5 and candidate in text:
                score += 45
                reasons.append(candidate)

            if len(candidate_squashed) >= 5 and candidate_squashed in squashed:
                score += 40
                reasons.append(candidate)

        if score > 0:
            scored.append((score, tool, reasons))

    scored.sort(key=lambda item: item[0], reverse=True)

    if not scored:
        log_event(f"tool map failed empty_match body={json.dumps(body, default=str)[:1000]}")
        return None

    # Avoid ambiguous ties. If the top score is clearly best, accept it.
    if len(scored) > 1 and scored[0][0] == scored[1][0]:
        log_event(
            "tool map ambiguous "
            + json.dumps(
                {
                    "top": [
                        {
                            "score": item[0],
                            "tool": item[1].get("display_name"),
                            "action_key": item[1].get("action_key"),
                            "reasons": item[2],
                        }
                        for item in scored[:3]
                    ],
                    "body": body,
                },
                default=str,
            )[:1600]
        )
        return None

    log_event(
        "tool map ok "
        + json.dumps(
            {
                "score": scored[0][0],
                "tool": scored[0][1].get("display_name"),
                "action_key": scored[0][1].get("action_key"),
                "reasons": scored[0][2][:5],
            },
            default=str,
        )
    )
    return scored[0][1]


# WT_LOCAL_BRIDGE_FOLDER_STATUS_FIX_20260628_START
def wt_folder_status_fix(tool):
    """Correct status for approved folder tools. Folders are valid targets."""
    try:
        if str(tool.get("kind", "")).lower() != "folder":
            return None

        raw_path = str(tool.get("expected_path", "") or tool.get("path", "")).strip()
        p = Path(raw_path)

        exists = p.exists()
        is_dir = p.is_dir()

        return {
            "key": tool.get("key"),
            "display_name": tool.get("display_name"),
            "category": tool.get("category"),
            "action_key": tool.get("action_key"),
            "kind": "folder",
            "path": str(p),
            "working_directory": str(tool.get("working_directory", "")),
            "launch_enabled": bool(tool.get("launch_enabled", False)),
            "exists": bool(exists and is_dir),
            "ready": bool(exists and is_dir and tool.get("launch_enabled", False)),
            "state": "ready" if exists and is_dir and tool.get("launch_enabled", False) else "missing",
            "size_bytes": None,
            "modified_epoch": None,
            "modified_local": None,
        }
    except Exception as exc:
        return {
            "key": tool.get("key"),
            "display_name": tool.get("display_name"),
            "category": tool.get("category"),
            "action_key": tool.get("action_key"),
            "kind": "folder",
            "path": str(tool.get("expected_path", "")),
            "working_directory": str(tool.get("working_directory", "")),
            "launch_enabled": bool(tool.get("launch_enabled", False)),
            "exists": False,
            "ready": False,
            "state": "error",
            "error": str(exc),
        }
# WT_LOCAL_BRIDGE_FOLDER_STATUS_FIX_20260628_END

def path_status(tool: Dict[str, Any]) -> Dict[str, Any]:
    raw_path = str(tool.get("expected_path", ""))
    p = Path(raw_path)

    # WT_LOCAL_BRIDGE_FOLDER_KIND_FIX_20260628
    if str(tool.get("kind", "")).lower() == "folder":
        exists = p.exists() and p.is_dir()
    else:
        exists = p.is_file()

    launch_enabled = bool(tool.get("launch_enabled", False))

    status: Dict[str, Any] = {
        "key": tool.get("key"),
        "display_name": tool.get("display_name"),
        "action_key": tool.get("action_key"),
        "category": tool.get("category"),
        "kind": tool.get("kind"),
        "path": raw_path,
        "exists": exists,
        "ready": exists and launch_enabled,
        "launch_enabled": launch_enabled,
        "state": "ready" if exists and launch_enabled else ("missing" if not exists else "disabled"),
        "working_directory": tool.get("working_directory"),
        "size_bytes": None,
        "modified_epoch": None,
        "modified_local": None,
    }

    if exists:
        st = p.stat()
        status["size_bytes"] = st.st_size
        status["modified_epoch"] = st.st_mtime
        status["modified_local"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime))

    return status


def approved_tool_statuses() -> List[Dict[str, Any]]:
    return [path_status(tool) for tool in configured_tools()]


def http_get_text(url: str, timeout: float = 4.0) -> Tuple[bool, int, str, str]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "WestTechHA-LocalBridge/0.10"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = resp.read()
            text = data.decode("utf-8", errors="replace")
            return True, int(getattr(resp, "status", 200)), text, ""
    except Exception as exc:
        return False, 0, "", str(exc)


def count_hits(text: str, needle: str) -> int:
    if not text or not needle:
        return 0
    return text.count(needle)


def server_status() -> Dict[str, Any]:
    app_ok, app_code, app_text, app_err = http_get_text(SERVER_PORTAL_URL + "/app.js")
    tools_ok, tools_code, tools_text, tools_err = http_get_text(SERVER_PORTAL_URL + "/api/v1/tools")
    files_ok, files_code, files_text, files_err = http_get_text(SERVER_PORTAL_URL + "/api/v1/business-files")

    return {
        "server_portal_url": SERVER_PORTAL_URL,
        "app_js": {
            "ok": app_ok,
            "http_status": app_code,
            "bytes": len(app_text.encode("utf-8")) if app_text else 0,
            "error": app_err,
            "v2_8_8_hits": count_hits(app_text, "v2.8.8"),
            "v2_8_7_hits": count_hits(app_text, "v2.8.7"),
            "local_bridge_consolidated_hits": count_hits(app_text, "WT_LOCAL_BRIDGE_CONSOLIDATED_A"),
            "direct_marker_hits": count_hits(app_text, "WT_FILES_3MF_DIRECT_RENDER_A"),
            "old_8787_hits": count_hits(app_text, "127.0.0.1:8787"),
            "bridge_8791_hits": count_hits(app_text, "127.0.0.1:8791"),
        },
        "tools_api": {
            "ok": tools_ok,
            "http_status": tools_code,
            "bytes": len(tools_text.encode("utf-8")) if tools_text else 0,
            "error": tools_err,
            "creality_print_hits": count_hits(tools_text, "Creality Print"),
            "esp32_production_tool_hits": count_hits(tools_text, "WestTech ESP32 Production Tool"),
            "website_updater_hits": count_hits(tools_text, "WestTechHA Website Updater"),
            "run_creality_print_hits": count_hits(tools_text, "run_creality_print"),
            "launch_production_tool_hits": count_hits(tools_text, "launch_production_tool"),
            "run_website_updater_hits": count_hits(tools_text, "run_website_updater"),
        },
        "business_files_api": {
            "ok": files_ok,
            "http_status": files_code,
            "bytes": len(files_text.encode("utf-8")) if files_text else 0,
            "error": files_err,
            "three_mf_hits": count_hits(files_text, ".3mf"),
        },
    }


def health_payload() -> Dict[str, Any]:
    return {
        "ok": True,
        "bridge_name": CONFIG.get("bridge_name", "WestTechHA Local Bridge"),
        "bridge_version": CONFIG.get("bridge_version", "0.10.0-hidden-tool-checks"),
        "mode": "hidden-tool-checks",
        "bind_host": BIND_HOST,
        "port": PORT,
        "time": now_iso(),
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "python": sys.version.split()[0],
        "server_portal_url": SERVER_PORTAL_URL,
        "allowed_actions": CONFIG.get("allowed_actions", []),
        "blocked_in_v0_4": CONFIG.get("blocked_in_v0_4", []),
    }


def tools_status_payload() -> Dict[str, Any]:
    local_tools = approved_tool_statuses()
    by_action = {str(t.get("action_key")): t for t in local_tools if t.get("action_key")}
    by_key = {str(t.get("key")): t for t in local_tools if t.get("key")}

    creality = by_action.get("run_creality_print") or by_key.get("creality_print") or {
        "path": "",
        "exists": False,
        "ready": False,
        "state": "missing",
    }

    return {
        "ok": True,
        "bridge_version": CONFIG.get("bridge_version", "0.10.0-hidden-tool-checks"),
        "mode": "hidden-tool-checks",
        "creality": creality,
        "local_tools": local_tools,
        "tools_by_action": by_action,
        "tools_by_key": by_key,
        "summary": {
            "tool_count": len(local_tools),
            "ready_count": sum(1 for t in local_tools if t.get("ready")),
            "missing_count": sum(1 for t in local_tools if not t.get("ready")),
            "launch_enabled_count": sum(1 for t in local_tools if t.get("launch_enabled")),
        },
        "server": server_status(),
        "local_cache": {
            "cache_dir": CONFIG.get("cache_dir"),
            "cache_exists": Path(str(CONFIG.get("cache_dir", ""))).is_dir(),
            "logs_dir": CONFIG.get("logs_dir"),
            "logs_exists": Path(str(CONFIG.get("logs_dir", ""))).is_dir(),
        },
        "actions": {
            "health": "enabled",
            "tools_status": "enabled",
            "approved_tool_launch": "enabled",
            "portal_api_compat_check": "enabled",
            "portal_api_compat_prereqs": "enabled",
            "custom_arguments": "blocked",
            "arbitrary_command": "blocked",
        },
    }


def run_cmd_no_window(args: List[str], cwd: str | None = None, timeout: float = 35.0) -> Tuple[bool, str]:
    # WT_LOCAL_BRIDGE_V010_HIDE_CHECK_SUBPROCESS_WINDOWS
    # v0.10: tool/prereq checks must not flash cmd/conhost windows.
    # This fixes ESPHome version checks such as: python.exe -m esphome version.
    try:
        kwargs: Dict[str, Any] = {
            "cwd": cwd,
            "capture_output": True,
            "text": True,
            "timeout": timeout,
        }
        if platform.system().lower() == "windows":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = 0
            kwargs["startupinfo"] = startupinfo
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        result = subprocess.run(args, **kwargs)
        text = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
        return result.returncode == 0, text or f"exit code {result.returncode}"
    except Exception as exc:
        return False, str(exc)

def launch_tool(action_key: str) -> Dict[str, Any]:
    tool = find_tool_by_action(action_key)
    if not tool:
        log_event(f"launch blocked unknown_action action_key={action_key!r}")
        return {"ok": False, "error": "unknown_or_unapproved_action", "action_key": action_key}

    # WT_LOCAL_BRIDGE_APPROVED_FOLDER_OPEN_PASS1C_START
    if str(tool.get("kind", "")).lower() == "folder":
        status = path_status(tool)
        if not status.get("launch_enabled"):
            return {"ok": False, "error": "launch_disabled", "tool": status}
        if not status.get("exists"):
            return {"ok": False, "error": "target_missing", "tool": status}

        folder_value = str(tool.get("expected_path") or tool.get("path") or "")
        folder = Path(folder_value)
        if not folder.is_dir():
            return {"ok": False, "error": "folder_missing", "tool": status}

        try:
            subprocess.Popen(["explorer.exe", str(folder)])
            log_event(f"folder opened action_key={action_key!r} folder={str(folder)!r}")
            return {
                "ok": True,
                "action_key": action_key,
                "message": "Folder opened in Explorer.",
                "tool": status,
            }
        except Exception as exc:
            log_event(f"folder open failed action_key={action_key!r} error={exc!r}")
            return {
                "ok": False,
                "error": "folder_open_failed",
                "action_key": action_key,
                "tool": status,
                "message": f"Explorer folder open failed: {exc}",
            }
    # WT_LOCAL_BRIDGE_APPROVED_FOLDER_OPEN_PASS1C_END
    status = path_status(tool)
    if not status.get("launch_enabled"):
        return {"ok": False, "error": "launch_disabled", "tool": status}
    if not status.get("exists"):
        return {"ok": False, "error": "target_missing", "tool": status}

    target = str(tool.get("expected_path", ""))
    cwd = str(tool.get("working_directory") or str(Path(target).parent))
    target_path = Path(target)
    cwd_path = Path(cwd)
    if not cwd_path.is_dir():
        cwd = str(target_path.parent)

    kind = str(tool.get("kind", "")).lower()
    try:
        # WT_LOCAL_BRIDGE_V07_DEBOUNCE_FOCUS
        # v0.7: protect tools from duplicate browser/portal launch posts and focus Creality Print.
        duplicate_window_seconds = 2.75
        global RECENT_LAUNCHES
        try:
            RECENT_LAUNCHES
        except NameError:
            RECENT_LAUNCHES = {}

        now = time.monotonic()
        last_launch = RECENT_LAUNCHES.get(action_key, 0)
        if (now - last_launch) < duplicate_window_seconds:
            log_event(f"duplicate launch ignored action_key={action_key!r} age={now-last_launch:.3f}s")
            return {
                "ok": True,
                "launched": False,
                "duplicate_ignored": True,
                "action_key": action_key,
                "message": f"Duplicate launch ignored for {action_key}.",
            }
        RECENT_LAUNCHES[action_key] = now

        def _run_hidden_powershell(script_text, wait=False):
            args = [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-WindowStyle",
                "Hidden",
                "-Command",
                script_text,
            ]
            if wait:
                return subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=12)
            return subprocess.Popen(args, cwd=cwd, shell=False)

        def _focus_creality(wait=False):
            focus_script = r'''
$code = 'using System; using System.Runtime.InteropServices; public class WTWin { [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd); [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow); }'
Add-Type -TypeDefinition $code -ErrorAction SilentlyContinue | Out-Null

$found = $false
for ($i = 0; $i -lt 30; $i++) {
  $procs = Get-Process -ErrorAction SilentlyContinue | Where-Object {
    $_.MainWindowHandle -ne 0 -and (
      $_.ProcessName -like '*Creality*' -or
      $_.MainWindowTitle -like '*Creality*'
    )
  }

  foreach ($p in $procs) {
    [WTWin]::ShowWindowAsync($p.MainWindowHandle, 9) | Out-Null
    Start-Sleep -Milliseconds 120
    [WTWin]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
    $found = $true
  }

  if ($found) { break }
  Start-Sleep -Milliseconds 250
}

if ($found) {
  Write-Output 'FOUND'
  exit 0
}
Write-Output 'NONE'
exit 2
'''
            return _run_hidden_powershell(focus_script, wait=wait)

        # WT_LOCAL_BRIDGE_V09_NO_CREality_FOCUS
        # v0.9: Creality Print launches immediately. No pre-focus scan.
        # Duplicate-launch guard remains active above.
        if platform.system().lower() == "windows" and action_key == "run_creality_print":
            pass

        visible_console = False
        if platform.system().lower() == "windows" and kind == "cmd":
            # v0.6/v0.7: .cmd tools are menu/console launchers. Open visible interactive console.
            proc = subprocess.Popen(
                ["cmd.exe", "/c", "start", "WestTechHA Local Tool", "/D", cwd, "cmd.exe", "/k", target],
                cwd=cwd,
                shell=False,
            )
            visible_console = True
        else:
            proc = subprocess.Popen([target], cwd=cwd, shell=False)

        # v0.9: no post-launch focus helper for Creality.
        # Windows focus restrictions made it unreliable, and it added overhead.

        log_event(f"launch allowed action_key={action_key!r} pid={proc.pid} target={target!r} visible_console={visible_console!r}")
        return {
            "ok": True,
            "launched": True,
            "action_key": action_key,
            "pid": proc.pid,
            "tool": status,
            "message": f"Launch requested through WestTechHA Local Bridge: {status.get('display_name')}",
            "note": "Approved allow-listed launch. No custom arguments were accepted.",
        }
    except Exception as exc:
        log_event(f"launch failed action_key={action_key!r} target={target!r} error={exc!r}")
        return {"ok": False, "error": "launch_failed", "message": str(exc), "tool": status}


def compat_tool_check(body: Dict[str, Any]) -> Dict[str, Any]:
    tool = find_tool_from_body(body)
    if not tool:
        return {
            "ok": False,
            "error": "unknown_tool",
            "message": "Local Bridge could not map the requested tool to an approved local tool.",
            "checks": [],
            "localBridge": True,
            "checkedBy": "WestTechHA Local Bridge",
        }

    status = path_status(tool)
    ready = bool(status.get("ready"))
    return {
        "ok": ready,
        "id": body.get("id") or status.get("key"),
        "tool": status.get("display_name"),
        "title": status.get("display_name"),
        "status": "Ready" if ready else "Needs Setup",
        "preflight": "Ready" if ready else "Needs Setup",
        "ready": ready,
        "canRun": ready,
        "canLaunch": ready,
        "serverViewerOnly": False,
        "localBridge": True,
        "checkedBy": "WestTechHA Local Bridge",
        "message": "Checked through WestTechHA Local Bridge on this PC.",
        "checks": [
            {
                "key": "local_target",
                "title": "Local target",
                "status": "Ready" if status.get("exists") else "Missing",
                "detail": status.get("path") or "",
                "exists": status.get("exists"),
                "ok": status.get("exists"),
            },
            {
                "key": "launch_permission",
                "title": "Launch permission",
                "status": "Ready" if status.get("launch_enabled") else "Blocked",
                "detail": "Approved allow-listed Local Bridge action: " + str(status.get("action_key")),
                "ok": status.get("launch_enabled"),
            },
        ],
        "toolStatus": status,
    }


def fw_paths() -> Dict[str, Path]:
    workspace = Path(str(CONFIG.get("firmware_workspace", r"C:\Users\ewest\Documents\WestTechHA-FW-Builder")))
    dash = workspace / "tools" / "esphome-dashboard"
    return {
        "workspace": workspace,
        "fw": workspace / "FW",
        "dash": dash,
        "install_ps1": dash / "Install-ESPHome.ps1",
        "start_ps1": dash / "Start-ESPHomeDashboard.ps1",
        "start_cmd": dash / "Start-WestTech-ESP32-Dashboard.cmd",
        "venv_python": dash / ".venv" / "Scripts" / "python.exe",
        "url": Path(""),
    }


ESP32_DASHBOARD_URL = "http://localhost:6052"


def probe_dashboard_url() -> Tuple[bool, str]:
    ok, code, _text, err = http_get_text(ESP32_DASHBOARD_URL, timeout=2.0)
    if ok:
        return True, f"Dashboard responded with HTTP {code} at {ESP32_DASHBOARD_URL}."
    return False, f"Dashboard not responding at {ESP32_DASHBOARD_URL}: {err}"


def esphome_version(python_path: Path) -> Tuple[bool, str]:
    if not python_path.is_file():
        return False, f"ESPHome venv Python is missing: {python_path}"
    ok, text = run_cmd_no_window([str(python_path), "-m", "esphome", "version"], cwd=str(python_path.parent), timeout=35.0)
    if ok:
        return True, text or "ESPHome version command passed."
    return False, text or "ESPHome version command failed."


def production_prereq_status(body: Dict[str, Any]) -> Dict[str, Any]:
    paths = fw_paths()
    fw_dir = paths["fw"]
    dash_dir = paths["dash"]
    install_ps1 = paths["install_ps1"]
    start_ps1 = paths["start_ps1"]
    start_cmd = paths["start_cmd"]
    venv_python = paths["venv_python"]

    fw_ready = fw_dir.is_dir()
    install_ready = install_ps1.is_file()
    dashboard_launcher_ready = start_ps1.is_file() or start_cmd.is_file()
    esphome_ok, esphome_detail = esphome_version(venv_python)
    dash_online, dash_detail = probe_dashboard_url()

    prereqs = [
        {
            "key": "firmware_folder",
            "title": "Firmware folder",
            "group": "Production workspace",
            "status": "Ready" if fw_ready else "Missing",
            "detail": str(fw_dir) if fw_ready else f"Missing: {fw_dir}",
            "canInstall": False,
        },
        {
            "key": "esphome_install_scripts",
            "title": "ESPHome install / launcher scripts",
            "group": "ESPHome Install / Launcher",
            "status": "Ready" if (install_ready and dashboard_launcher_ready) else "Missing",
            "detail": str(dash_dir) if (install_ready and dashboard_launcher_ready) else f"Missing install/start scripts under {dash_dir}",
            "canInstall": True,
        },
        {
            "key": "esphome_environment",
            "title": "ESPHome environment",
            "group": "ESPHome Install / Launcher",
            "status": "Ready" if esphome_ok else "Missing",
            "detail": esphome_detail,
            "canInstall": True,
        },
        {
            "key": "dashboard_running",
            "title": "ESPHome Dashboard",
            "group": "ESPHome Install / Launcher",
            "status": "Running" if dash_online else "Stopped",
            "detail": dash_detail,
            "canStart": esphome_ok and dashboard_launcher_ready,
            "canOpen": True,
            "url": ESP32_DASHBOARD_URL,
        },
    ]

    ready = fw_ready and install_ready and dashboard_launcher_ready and esphome_ok
    needs_install = (not install_ready) or (not dashboard_launcher_ready) or (not esphome_ok)

    return {
        "ok": True,
        "tool": "WestTech ESP32 Production Tool",
        "workspaceRoot": str(paths["workspace"]),
        "dashboardDir": str(dash_dir),
        "installScript": str(install_ps1),
        "startScript": str(start_cmd if start_cmd.is_file() else start_ps1),
        "target": str(find_tool_by_action("launch_production_tool").get("expected_path", "")) if find_tool_by_action("launch_production_tool") else "",
        "url": ESP32_DASHBOARD_URL,
        "canManage": True,
        "ready": ready,
        "needsInstall": needs_install,
        "dashboardRunning": dash_online,
        "canStart": bool(esphome_ok and dashboard_launcher_ready),
        "localBridge": True,
        "checkedBy": "WestTechHA Local Bridge",
        "prereqs": prereqs,
        "message": "Checked through WestTechHA Local Bridge on this PC.",
        "serverViewerOnly": False,
    }


def start_dashboard() -> Dict[str, Any]:
    paths = fw_paths()
    start_cmd = paths["start_cmd"]
    start_ps1 = paths["start_ps1"]
    dash_dir = paths["dash"]

    try:
        if start_cmd.is_file():
            proc = subprocess.Popen(str(start_cmd), cwd=str(dash_dir), shell=True)
            return {"ok": True, "localBridge": True, "message": f"ESPHome Dashboard start requested through Local Bridge. PID={proc.pid}", "pid": proc.pid}
        if start_ps1.is_file():
            proc = subprocess.Popen(["powershell.exe", "-ExecutionPolicy", "Bypass", "-File", str(start_ps1)], cwd=str(dash_dir), shell=False)
            return {"ok": True, "localBridge": True, "message": f"ESPHome Dashboard start requested through Local Bridge. PID={proc.pid}", "pid": proc.pid}
        return {"ok": False, "localBridge": True, "error": "start_script_missing", "message": f"Dashboard start script missing under {dash_dir}"}
    except Exception as exc:
        return {"ok": False, "localBridge": True, "error": "start_failed", "message": str(exc)}


def install_esphome() -> Dict[str, Any]:
    # v0.4 deliberately does not run the heavier ESPHome install/repair step yet.
    # The check endpoint exposes the exact install script path so Ed can approve this later.
    paths = fw_paths()
    return {
        "ok": False,
        "localBridge": True,
        "error": "install_not_enabled_in_v0_4",
        "message": "Local Bridge v0.4 checks ESPHome prerequisites but does not run Install-ESPHome yet. This needs a separate approval step.",
        "installScript": str(paths["install_ps1"]),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "WestTechHALocalBridge/0.10"

    def _is_local_client(self) -> bool:
        host = self.client_address[0]
        return host in ("127.0.0.1", "::1", "localhost")

    def _read_json_body(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0:
            return {}
        if length > 16384:
            raise ValueError("body_too_large")
        raw = self.rfile.read(length)
        if not raw:
            return {}
        return json.loads(raw.decode("utf-8"))

    def _send_json(self, status: int, payload: Dict[str, Any]) -> None:
        body = json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
        origin = self.headers.get("Origin", "")

        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")

        if origin in ALLOWED_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        if not self._is_local_client():
            self._send_json(403, {"ok": False, "error": "local_clients_only"})
            return
        origin = self.headers.get("Origin", "")
        self.send_response(204)
        if origin in ALLOWED_ORIGINS:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Allow-Private-Network", "true")
        self.end_headers()

    def do_GET(self) -> None:
        if not self._is_local_client():
            self._send_json(403, {"ok": False, "error": "local_clients_only"})
            return

        path = self.path.split("?", 1)[0].rstrip("/") or "/"

        if path == "/health":
            self._send_json(200, health_payload())
        elif path == "/tools/status":
            self._send_json(200, tools_status_payload())
        elif path == "/debug/routes":
            self._send_json(200, {
                "ok": True,
                "routes": [
                    "GET /health",
                    "GET /tools/status",
                    "GET /debug/routes",
                    "POST /tools/launch",
                    "POST /api/v1/tools/check",
                    "POST /api/v1/tools/prepare",
                    "POST /api/v1/tools/launch",
                    "POST /api/v1/tools/production-prereqs",
                    "POST /api/v1/tools/production-prereqs/start-dashboard",
                    "POST /api/v1/tools/production-prereqs/install-esphome",
                    "POST /api/v1/tools/production-prereqs/install-dashboard",
                    "OPTIONS *",
                ],
                "blocked": [
                    "No arbitrary commands",
                    "No arbitrary paths",
                    "No caller-supplied args",
                    "ESPHome install/repair not enabled in v0.4",
                ],
            })
        else:
            self._send_json(404, {"ok": False, "error": "not_found", "path": path})

    def do_POST(self) -> None:
        if not self._is_local_client():
            self._send_json(403, {"ok": False, "error": "local_clients_only"})
            return

        path = self.path.split("?", 1)[0].rstrip("/") or "/"

        try:
            body = self._read_json_body()
        except Exception as exc:
            self._send_json(400, {"ok": False, "error": "bad_json", "message": str(exc)})
            return

        if path == "/tools/launch":
            action_key = str(body.get("action_key", "")).strip()
            forbidden = ["path", "command", "cmd", "exe", "args", "arguments", "working_directory"]
            present_forbidden = [k for k in forbidden if k in body]
            if present_forbidden:
                self._send_json(400, {"ok": False, "error": "forbidden_fields", "fields": present_forbidden})
                return
            result = launch_tool(action_key)
            self._send_json(200 if result.get("ok") else 400, result)
            return

        if path == "/api/v1/tools/check":
            self._send_json(200, compat_tool_check(body))
            return

        if path == "/api/v1/tools/prepare":
            result = compat_tool_check(body)
            result["prepared"] = bool(result.get("ready"))
            result["message"] = "Prepared through WestTechHA Local Bridge." if result.get("ready") else result.get("message")
            self._send_json(200 if result.get("ok") else 400, result)
            return

        if path == "/api/v1/tools/launch":
            tool = find_tool_from_body(body)
            if not tool:
                self._send_json(400, {"ok": False, "error": "unknown_tool", "message": "Could not map id to approved Local Bridge action."})
                return
            result = launch_tool(str(tool.get("action_key", "")))
            self._send_json(200 if result.get("ok") else 400, result)
            return

        if path == "/api/v1/tools/production-prereqs":
            self._send_json(200, production_prereq_status(body))
            return

        if path == "/api/v1/tools/production-prereqs/start-dashboard":
            result = start_dashboard()
            self._send_json(200 if result.get("ok") else 400, result)
            return

        if path in ("/api/v1/tools/production-prereqs/install-esphome", "/api/v1/tools/production-prereqs/install-dashboard"):
            result = install_esphome()
            self._send_json(400, result)
            return

        self._send_json(404, {"ok": False, "error": "not_found", "path": path})

    def log_message(self, fmt: str, *args: Any) -> None:
        log_dir = Path(str(CONFIG.get("logs_dir", BRIDGE_ROOT / "logs")))
        log_dir.mkdir(parents=True, exist_ok=True)
        with (log_dir / "bridge-http.log").open("a", encoding="utf-8") as f:
            f.write(f"{now_iso()} {self.client_address[0]} {fmt % args}\n")


def main() -> int:
    BRIDGE_ROOT.mkdir(parents=True, exist_ok=True)
    Path(str(CONFIG.get("cache_dir", BRIDGE_ROOT / "cache"))).mkdir(parents=True, exist_ok=True)
    Path(str(CONFIG.get("logs_dir", BRIDGE_ROOT / "logs"))).mkdir(parents=True, exist_ok=True)

    PID_PATH.write_text(str(os.getpid()), encoding="utf-8")

    httpd = ThreadingHTTPServer((BIND_HOST, PORT), Handler)
    try:
        print(f"WestTechHA Local Bridge v0.10 listening on http://{BIND_HOST}:{PORT}", flush=True)
        httpd.serve_forever()
    finally:
        try:
            PID_PATH.unlink(missing_ok=True)
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())





