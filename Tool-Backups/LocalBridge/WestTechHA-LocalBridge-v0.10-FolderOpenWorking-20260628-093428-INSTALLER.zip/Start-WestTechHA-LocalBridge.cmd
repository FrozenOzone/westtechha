@echo off
setlocal

set "BRIDGE_ROOT=%LOCALAPPDATA%\WestTechHA\LocalBridge"
set "PYTHON_EXE=C:\Python314\python.exe"
set "BRIDGE_SCRIPT=%BRIDGE_ROOT%\WestTechHA-LocalBridge-v0.10.py"

if not exist "%PYTHON_EXE%" (
  echo ERROR: Python not found:
  echo   %PYTHON_EXE%
  pause
  exit /b 1
)

if not exist "%BRIDGE_SCRIPT%" (
  echo ERROR: Bridge script not found:
  echo   %BRIDGE_SCRIPT%
  pause
  exit /b 1
)

cd /d "%BRIDGE_ROOT%"
start "WestTechHA Local Bridge" /min "%PYTHON_EXE%" -u "%BRIDGE_SCRIPT%"
exit /b 0
